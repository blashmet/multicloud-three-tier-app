#######IMPORT AWS MODULE##############

Import-Module AWSPowerShell


####DISABLE DEFAULT WEB SITE######

#cmd.exe /c "%systemroot%\system32\inetsrv\AppCmd.exe stop site /site.name:""Default Web Site"""

#cmd.exe /c "%systemroot%\system32\inetsrv\AppCmd.exe delete site /site.name:""Default Web Site"""

#cmd.exe /c "%systemroot%\system32\inetsrv\AppCmd.exe add site /name:""Default Web Site"" /id:""1"" /physicalPath:""C:\inetpub\wwwroot"" /bindings:"""""

#cmd.exe /c "%systemroot%\system32\inetsrv\AppCmd.exe stop site /site.name:""Default Web Site"""

####STOP APP POOL###

#cmd.exe /c "%systemroot%\system32\inetsrv\AppCmd.exe stop apppool /apppool.name:DefaultAppPool"

#cmd.exe /c "%systemroot%\system32\inetsrv\AppCmd.exe delete apppool /apppool.name:DefaultAppPool"


####DELETE APP POOL###

#cmd.exe /c "%systemroot%\system32\inetsrv\AppCmd.exe stop apppool /apppool.name:WebSites"

#cmd.exe /c "%systemroot%\system32\inetsrv\AppCmd.exe delete apppool /apppool.name:WebSites"

#########CLEAR SITE DIRECTORIES#########

cmd.exe /c 'pushd "c:\inetpub\wwwroot" && (rd /s /q "c:\inetpub\wwwroot" 2>nul & popd)'

#####DEPLOY PACKAGE#########

Add-Type -AssemblyName System.IO.Compression.FileSystem

$SitesSource = "killer-demo-ui-site-contents.zip"

$SitePath = "c:\inetpub\wwwroot"

[System.IO.Compression.ZipFile]::ExtractToDirectory($SitesSource, $SitePath)

####CREATE APP POOL###

#cmd.exe /c "%systemroot%\system32\inetsrv\AppCmd.exe add apppool /name:WebSites /managedRuntimeVersion:"""" /managedPipelineMode:""Integrated"""

####CREATE SITES#####

#ForEach($site in $Sites){

#cmd.exe /c "%systemroot%\system32\inetsrv\AppCmd.exe add site /name:""$($site.name)"" /id:""$($site.id)"" /physicalPath:""$($site.physicalpath)"" /bindings:""$($site.bindings -join ",")"""

#cmd.exe /c "%systemroot%\system32\inetsrv\AppCmd.exe set app ""$($site.name)/"" /applicationPool:""WebSites"""

#}
